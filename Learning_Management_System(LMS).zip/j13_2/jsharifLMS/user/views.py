from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.contrib import auth
from django.contrib.auth.models import User

def User_Saved_Page(request):
    username = request.POST["username"];
    password = request.POST["password"];
    email = request.POST["email"];
    User.objects.create_user(username,email,password);
    return HttpResponse("<h1>user saved</h1>")

def Student_Home_Page(request):
    username = request.POST["username"];
    password = request.POST["password"];
    userObject = auth.authenticate(username = username , password = password);
    if userObject:
        auth.login(request,userObject)
        return render(request,"Student_Home_Page.html")
    else:
        return HttpResponse("<h1>Login failed, make sure user name and password are correct or you are registered in the system.</h1>")

def Professor_Home_Page(request):
    return render(request,"Professor_Home_Page.html")
