from django.db import models

# Create your models here.

class Department(models.Model):
    title = models.CharField(max_length = 30);

class Course(models.Model):
    code = models.CharField(max_length = 10);
    title = models.CharField(max_length = 50);
    #Define the Foreign key for course table. This forieng key will relate table course to table department.
    department = models.ForeignKey(Department,null=True, on_delete = models.CASCADE);
