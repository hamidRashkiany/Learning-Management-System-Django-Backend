from django.contrib import admin

# Register your models here.
from course.models import Course,Department
class CourseAdmin(admin.ModelAdmin):
    list_display=("code","title","department_id");

class DepartmentAdmin(admin.ModelAdmin):
    list_display=("title",);

admin.site.register(Course,CourseAdmin);
admin.site.register(Department,DepartmentAdmin);
