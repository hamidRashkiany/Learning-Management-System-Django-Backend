from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from course.models import Course,Department
from django.contrib.auth.decorators import login_required
def Department_Courses_Page(request,offset):
    departmentCourses = Course.objects.filter(department = Department.objects.get(id=int(offset)));
    return render(request, "Department_Courses_Page.html",{'department_course_list_ds':departmentCourses})

def Show_Course_Page(request):
    if request.user.is_authenticated:
        courseList=Course.objects.all();
        return render(request,"Show_Course_Page.html",{'course_list_ds':courseList})
    else:
        return HttpResponse("<h1>Login required</h1>")

@login_required(login_url='/login')
def Show_Department_Page(request):
    departmentList=Department.objects.all();
    return render(request,"Show_Department_Page.html",{'department_list_ds':departmentList})
   # return HttpResponse("<h1>Deparment list</h1>")
   
