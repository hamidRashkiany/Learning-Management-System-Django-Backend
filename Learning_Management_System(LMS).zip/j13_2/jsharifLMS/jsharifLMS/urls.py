"""jsharifLMS URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path
from mainPage.views import Home_Page,Register_Page,Login_Page,Logout_Page
from course.views import Show_Course_Page,Show_Department_Page,Department_Courses_Page
from user.views import Student_Home_Page, Professor_Home_Page,User_Saved_Page

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',Home_Page),
    path('home/',Home_Page),
    path('register',Register_Page),
    path('save_user',User_Saved_Page),
    path('login',Login_Page),
    path('logout',Logout_Page),
    path('courses',Show_Course_Page),
    path('departments',Show_Department_Page),
    re_path('^department_courses/(\d+)$',Department_Courses_Page),
    path("Student_Home_Page",Student_Home_Page),
    path("Professor_Home_Page",Professor_Home_Page),
]
