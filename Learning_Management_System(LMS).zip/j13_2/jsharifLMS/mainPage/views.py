from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from django.contrib import auth
def Home_Page(request):
    return render(request,'index.html')
#    return HttpResponse("<h1>Welcome to our website. :))</h1>")
def Register_Page(request):
    return render(request,"Register_Page.html")
   # return HttpResponse("<h1>Please register your self</h1>")

def Login_Page(request):
    return render(request,'Login_Page.html')
   # return HttpResponse("<h1>You are in Login Page. Please enter your user name and password.</h1>")

def Logout_Page(request):
    auth.logout(request)
    return render(request,"Logout_Page.html")
   # return HttpResponse("<h1>Thanks for see our website</h1>")
